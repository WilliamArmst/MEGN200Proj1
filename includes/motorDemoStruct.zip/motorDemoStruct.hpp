#ifndef MOTOR_DEMO_STRUCT_HPP
#define MOTOR_DEMO_STRUCT_HPP

struct DataPacket {
	int speed = 0;
	int isReversed = false; 
}; // something

#endif